#include <stdint.h>
#include <stddef.h>
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>
#include "ti_drivers_config.h"

volatile unsigned char TimerFlag = 0; // ISR raises, main() lowers

static char SOS_sequence[] = "***---***";
static char OK_sequence[] = "----*-";
static char* currentSequence; // Pointer to the current sequence
static int sequenceIndex = 0; // Index to track position in the sequence
static int i = 0; // Counter variable for timing control

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1; // Set the flag to trigger the state machine
}

enum MC_States {
    MC_Start,
    MC_Dot,        // Short blink state for *
    MC_Dash,       // Long blink state for -
    MC_ShortOff,   // Short off period between blinks
    MC_CharGap,    // Gap between characters
    MC_WordGap     // Gap between words
} MC_State;

volatile unsigned char toggleMessage = 0; // Flag to toggle between SOS and OK

void gpioButtonFxn0(uint_least8_t index)
{
    toggleMessage = 1; // Set the flag to toggle the message after the current one completes
}

char nextChar(char* sequence, int* index) {
    if (sequence[*index] != '\0') {
        return sequence[(*index)++];
    } else {
        *index = 0; // Reset index after the sequence is done
        return '\0'; // Indicate the end of the sequence
    }
}

void TickFct_MorseCode() {
    switch (MC_State) { // Transitions
        case MC_Start:
            currentSequence = SOS_sequence; // Start with SOS
            MC_State = MC_ShortOff;
            break;

        case MC_Dot:
            if (i < 1) {  // Keep LED on for 1 cycle (500 ms) for a dot
                i++;
            } else {
                i = 0;
                MC_State = MC_ShortOff; // Turn off after the dot duration
            }
            break;

        case MC_Dash:
            if (i < 3) {  // Keep LED on for 3 cycles (1500 ms) for a dash
                i++;
            } else {
                i = 0;
                MC_State = MC_ShortOff; // Turn off after the dash duration
            }
            break;

        case MC_ShortOff:
            {
                char next = nextChar(currentSequence, &sequenceIndex);
                if (next == '*') {
                    MC_State = MC_Dot;
                } else if (next == '-') {
                    MC_State = MC_Dash;
                } else if (next == '\0') {
                    MC_State = MC_WordGap; // End of the sequence
                }
            }
            break;

        case MC_CharGap:
            MC_State = MC_ShortOff;
            break;

        case MC_WordGap:
            if (toggleMessage) {
                currentSequence = (currentSequence == SOS_sequence) ? OK_sequence : SOS_sequence;
                toggleMessage = 0;
            }
            sequenceIndex = 0; // Reset the sequence
            MC_State = MC_ShortOff; // Restart the sequence
            break;

        default:
            MC_State = MC_Start;
            break;
    }

    switch (MC_State) { // State actions
        case MC_Start:
            break;

        case MC_Dot:
            GPIO_write(CONFIG_GPIO_LED_0, 1); // Short blink (Dot)
            break;

        case MC_Dash:
            GPIO_write(CONFIG_GPIO_LED_1, 1); // Long blink (Dash)
            break;

        case MC_ShortOff:
        case MC_CharGap:
        case MC_WordGap:
            GPIO_write(CONFIG_GPIO_LED_0, 0); // LEDs off
            GPIO_write(CONFIG_GPIO_LED_1, 0);
            break;
    }
}

void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);

    // Set the period to 500000 us (500 ms)
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialize timer */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();
    initTimer();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /* Initialize state machine */
    MC_State = MC_Start;

    while (1) {
        if (TimerFlag) { // Check if timer has triggered
            TickFct_MorseCode(); // Execute one state machine tick
            TimerFlag = 0; // Lower flag
        }
    }
}
